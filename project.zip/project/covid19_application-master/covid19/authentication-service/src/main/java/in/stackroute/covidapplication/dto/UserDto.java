package in.stackroute.covidapplication.dto;

import lombok.Data;

@Data
public class UserDto {
    private String email;
    private String userName;
    private String password;

}
