# Covid19_Application

Shivam Jagtap , Sahana Godwa , Vijay Prakash , Chintha Nikhitha