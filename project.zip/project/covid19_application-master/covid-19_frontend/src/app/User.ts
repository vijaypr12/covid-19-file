export class User {
    email: string;
    userName: string;
    password: string;
    oldPassword: string;
    newPassword: string;
  }