export class Ccountry {
    
    // name: String;
    country:string;
    infected: string;
    recovered: String;
    deceased:string;
  }